DataPraxis arXiv source package

Template: supplied AMoA arXiv package, longcat_style.sty.
Main file: arxiv.tex
Compiler: pdfLaTeX

All figures, Logo.pdf, local styles, bibliography and arxiv.bbl are included.
Compile with: latexmk -pdf arxiv.tex

The anonymous conference submission and previous arXiv package remain separate.
