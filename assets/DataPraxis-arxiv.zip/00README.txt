DataPraxis arXiv source package

Main file: arxiv.tex
Compiler: pdfLaTeX

All figures, local style files, bibliography source, and arxiv.bbl are
included. No shell escape or external downloads are required.

Compile: latexmk -pdf arxiv.tex
Or run pdflatex, bibtex, then pdflatex twice on arxiv.

This is the non-anonymous preprint edition. The conference submission
is maintained separately and is not included in this upload package.
